# SimuAlpha Design System

> **SimuAlpha democratizes alpha — the edge that used to cost $2,000/mo at a Bloomberg Terminal, now $10/mo for retail investors.** An AI-powered stock discovery engine that scans the S&P 500 daily, cross-references 8 super investors, politician trades, AI model portfolios, and its own proprietary TLI score — and hands you a single verdict per stock.

The brand is built for *serious retail investors who want institutional-grade intelligence without the institutional price tag*. Aesthetically, that means: **dark, data-dense, quietly confident.** A Bloomberg Terminal, but curated by a private banker — not shouting at you.

---

## Index

| Path | What's there |
|------|--------------|
| **`README.md`** | You are here. Brand context + content + visual foundations + iconography. |
| **`colors_and_type.css`** | All CSS custom properties (tokens) + semantic type roles. Drop into any prototype. |
| **`SKILL.md`** | Agent-invocable entry point for Claude Code and skill-aware hosts. |
| **`assets/`** | Logos, OG images, example screenshots, icon set (Lucide via CDN). |
| **`preview/`** | Small HTML cards that populate the Design System tab — swatches, type specimens, component states. |
| **`ui_kits/marketing/`** | Landing page UI kit — nav, hero, feature grid, compare table, pricing. |
| **`ui_kits/app/`** | App UI kit — dashboard, screener table, deep-dive cards, signal badges. |
| **`sources/simualpha/`** | Source-of-truth extract from the live codebase. Do not edit; reference only. |

---

## Product surfaces

SimuAlpha is **one codebase, two very different UIs** glued together at `/` vs `/dashboard`:

| Surface | Route | Character |
|---------|-------|-----------|
| **Marketing / Landing** | `/` | Spacious. Hero-driven. Cormorant display headlines at `clamp(44px, 12vw, 112px)`. One green CTA, one outline CTA, long-scroll sections. |
| **App** | `/dashboard`, `/screener`, `/ticker/:sym`, `/signals`, `/investors`, `/agent`, `/my`, `/market`, `/backtesting` | Dense. Utilitarian. Tables with 11px mono, score rings, signal badges, inline metric cards. Cormorant still shows up for page titles, but the workhorse is IBM Plex Mono. |

Both share the **same tokens** (`--bg-primary`, `--signal-green`, `--font-display`, `--font-mono`). The only shift is *scale* and *density* — not color or type.

---

## Sources

Everything in this design system was extracted from a single repo. If you need to verify anything, go here:

- **Main repo:** https://github.com/crazymonkey-1470/SimuAlpha @ `main`
- **Live frontend source:** `frontend/src/` — React 18 + Vite + Tailwind + Framer Motion
- **Their in-repo design doc:** `DESIGN_SYSTEM.md` *(⚠︎ stale — describes a Syne + DM Mono aesthetic that the code does NOT actually use; I followed the code over the doc.)*
- **Their README:** `README.md` (23KB — full product spec)

Local snapshot of the files I read is in `sources/simualpha/`.

---

# Content fundamentals

SimuAlpha's voice is **confident, technical, slightly literary.** It borrows from three registers and blends them:

1. **Classical investing** — *"Load the boat,"* *"The Long Investor,"* *"Generational support zones."* Weighty, patient, Buffett-adjacent.
2. **Systems engineering** — *"4-layer consensus,"* *"TLI v2 algorithm,"* *"200 Weekly Moving Average."* Precise, quantitative, numbered.
3. **Direct second-person** — *"Find what deserves your attention."* *"Ready to find your next opportunity?"*

No marketing fluff, no exclamation points, no emoji in prose. When a feeling is conveyed, it's through **typography (italic Cormorant) and negative space**, not adjectives.

## Tone rules

| Rule | Yes | No |
|------|-----|-----|
| **Pronoun** | "you" — second-person, direct | "we" for the product; "our users"; "investors like you" |
| **Case** | Sentence case for most copy. UPPERCASE for labels, tags, signals (`LOAD THE BOAT`, `ACCUMULATE`, `MARKET CONTEXT`) | Title Case Everywhere |
| **Verdicts over opinions** | "One score. One verdict. The system decides what's worth your time so you don't have to." | "Our expert analysts believe..." |
| **Density is a feature** | "DCF + EV/Sales + EV/EBITDA composite rating" | "Comprehensive valuation analysis" |
| **Numbers as nouns** | "8 super investors," "19+ sources," "500+ stocks scored daily" | "many," "dozens of," "lots of" |
| **Emoji in prose** | Never. | 🚀 📊 💡 |
| **Emoji as glyphs in badges** | Sparingly — ⏳ ⚠️ 💎 appear in signal labels (see `SignalBadge.jsx`). | Decorative emoji in UI chrome. |
| **Punctuation** | Em-dashes for emphasis. Short sentences. Periods on every bullet. | Exclamation points. Ellipses for drama. |

## Voice exemplars (verbatim from the product)

- **Headline:** *"Democratizing **Alpha**"* (italic green on the last word — the signature pattern)
- **Subhead:** *"An autonomous system powered by cutting-edge AI — built on decades of investing wisdom from history's greatest investors…"*
- **CTA:** *"Join on Patreon"* / *"Start Screening"* / *"Open Screener"* — one verb, short, never "Learn More"
- **Feature intro:** *"Four Layers of Intelligence. **One Clear Answer.***" — tension-release structure, italic muted second line
- **Plan tagline:** *"Bloomberg charges $2,000/mo. SimuAlpha is $10."* — price as proof, not pitch
- **Signal copy:** `LOAD THE BOAT` • `ACCUMULATE` • `WATCH` • `TRIM` • `VALUE TRAP` • `WAVE C — ENTRY ZONE` — all caps, imperative, domain-fluent
- **Footer disclaimer:** *"Not financial advice. AI-generated analysis for educational purposes only. Do your own research before investing."* — always present, never buried

## Vibe

Think: **the private research note a hedge-fund analyst would leave on their terminal at midnight.** Cormorant serif where a human is addressing you ("Ready to find your next opportunity?"), Plex Mono where the machine is reporting back ("S&P P/E: 22.4x (vs 17x avg)"). The brand treats its user as someone who already knows what EV/EBITDA means.

---

# Visual foundations

## Palette

**Every color has a meaning.** If you're using a color decoratively, you're off-brand.

| Role | Token | Hex | When to use |
|------|-------|-----|-------------|
| Page | `--bg-primary` | `#0c0c0e` | Always. Near-black with a hint of warmth. Not `#000`. |
| Section band | `--bg-secondary` | `#111114` | Alternating section strips on long scrolls (Compare table, Pricing). |
| Card | `--bg-card` | `#16161a` | Default surface. Every container. |
| Card hover | `--bg-card-hover` | `#1c1c21` | Hover raise on interactive cards. |
| Border | `--border` | `#222228` | Default hairline. All cards, dividers, tables. |
| Border emphasis | `--border-light` | `#2a2a32` | Hover state; active nav item. |
| **Primary signal** | `--signal-green` | `#00e87a` | Conviction. CTA backgrounds. "LOAD THE BOAT". Primary metric values. The italic accent word. |
| Primary signal tint | `--signal-green-dim` | `#00e87a18` (~9% α) | Backgrounds of green badges, success highlight bands. |
| Caution | `--signal-amber` | `#f0a500` | "ACCUMULATE", "WATCH", "Late Cycle" risk. Warnings that are not failures. |
| Caution tint | `--signal-amber-dim` | `#f0a50018` | Amber badge backgrounds. |
| Danger | `--red` | `#e84444` | "VALUE TRAP", "THESIS BROKEN", negative deltas, exit signals. |
| Info | `--blue` | `#4a9eff` | Wave bonuses, AI Model layer, neutral informational highlights. |
| Rarest tier | `--gold` | `#c9a84c` | Reserved for Full-Stack Consensus — the highest-conviction signal. Never used elsewhere. |
| Text | `--text-primary` | `#f0ede8` | **Warm cream**, not pure white. Signature choice. |
| Text secondary | `--text-secondary` | `#8a8a9a` | Body, labels. |
| Text dim | `--text-dim` | `#3a3a4a` | Timestamps, meta, disabled. |

## Typography

Two families. That's it.

- **Cormorant Garamond** — serif, weights 300/400/500/600 + italics 300/400. Used for:
  - Every h1/h2/h3 (page titles, section headers, card titles)
  - Pricing numbers (`$10`, `$0`)
  - Italic accent words: *Alpha, Screener, One Clear Answer*
  - Empty-state messages ("No data yet")
  - Used at weight **300** for display sizes — never bold for headlines.
- **IBM Plex Mono** — monospace, weights 300/400/500 (600 for CTAs). Used for everything else:
  - All body copy
  - Every number, ticker, score, percentage
  - Nav links, buttons, labels, flags
  - Tables, data rows
  - All UPPERCASE labels with `letter-spacing: 0.08–0.12em`

**Text sizing is intentionally tiny** for data density: **9px, 10px, 11px, 12px** cover 90% of the app. Anything above 14px is a display element.

## Backgrounds & textures

1. **Near-black (`#0c0c0e`) across every surface.** There is no light mode.
2. **Noise grain overlay** — a subtle SVG `feTurbulence` noise layer is `position: fixed` on every page at `opacity: 0.4` with `base-frequency=0.9`. This is the signature atmospheric texture — always on, always unobtrusive. See `body::before` in `colors_and_type.css`.
3. **No hero gradients, no mesh, no glows on page backgrounds.** The one exception: the Full-Stack Consensus banner uses a subtle gold gradient (`linear-gradient(135deg, rgba(201,168,76,0.12), rgba(240,165,0,0.10), rgba(201,168,76,0.08))`) because that specific signal is meant to feel ceremonial.
4. **Scan-line effect** on dashboard load — a single thin green line sweeps vertically once, 4s duration. Called out with `@keyframes scan-line`. Cyberpunk nod, used sparingly.
5. **No illustrations, no photography, no abstract imagery.** The product never uses decorative images. Data is the imagery.

## Spacing

SimuAlpha uses **direct pixel values** inline (`padding: '14px 32px'`) rather than a strict token scale. The *observed* rhythm:

- Micro (inside tags, badges): 2–4px vertical, 6–10px horizontal
- Small (card padding): **20px** or **16px 20px**
- Medium (button padding): **14px 32px** (hero), **12px 24px** (secondary), **8px 16px** (nav CTA)
- Large (section internal): **28px** — card content padding
- Section gap: **48–64px** between app sections, **80–96px** between landing sections
- Top-level padding: pages start at `paddingTop: '40–48px'`

The `colors_and_type.css` exposes `--space-1..--space-24` for consistency in new work.

## Borders & corners

**Sharp, but not brutal.** Corner radii are subtle:

| Element | Radius |
|---------|--------|
| Micro tags / flags | `3–4px` |
| Badges | `4px` |
| Buttons, nav links, small tags | `6px` |
| Smaller cards, banners | `8px` |
| **Primary cards (the dominant card style)** | `12px` |

Borders are **always `1px`**, always `var(--border)` or `var(--border-light)`. Hover states swap to the lighter border, never to a glow. A highlighted card may use `2px solid var(--signal-green)` (pricing "Most Popular" tier).

## Shadows

**There are essentially no shadows.** SimuAlpha uses `border` where most systems would use `box-shadow`. The *only* place `box-shadow` appears in the codebase is the pulsing green glow on active signals:

```css
@keyframes pulse-green {
  0%, 100% { box-shadow: 0 0 0 0 rgba(0, 232, 122, 0.4); }
  50%      { box-shadow: 0 0 0 8px rgba(0, 232, 122, 0); }
}
```

No elevation system, no ambient shadow, no `0 4px 8px rgba(0,0,0,.1)` anywhere. Depth comes from borders and slight bg lightening.

## Blur & transparency

Used in exactly two places:

1. **Sticky navigation** — `background: rgba(12,12,14,0.85)` + `backdrop-filter: blur(12px)` on both the landing nav and the app NavBar. Glassmorphism exists only on the fixed top chrome.
2. **Mobile hamburger menu** — same treatment, `rgba(12,12,14,0.98)` + `blur(16px)`.

Everywhere else: fully opaque solid surfaces.

## Hover & press states

- **Hover on cards:** border transitions from `--border` → `--border-light` over `0.15s ease`. Sometimes also `background: --bg-card-hover`.
- **Hover on text links / nav links:** color transitions from `--text-secondary` → `--text-primary` over `0.15s`.
- **Hover on buttons:** no scale, no shadow. Border color shift or subtle `opacity` change.
- **Press state:** not explicitly styled. Framer Motion's `whileHover` is used on a few cards (Full-Stack Consensus rows) but there is no codified `:active` transform.

## Motion

Framer Motion is the motion library. Patterns used repeatedly:

| Pattern | Code |
|---------|------|
| **Entrance fade-up** | `initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}` with `transition={{ duration: 0.4 }}` |
| **Staggered list** | Each child gets `transition={{ delay: i * 0.04 }}` — fast, 40ms increments |
| **Scroll reveal** | `whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}` — fire once, never replay |
| **Score ring fill** | CSS transition on `stroke-dashoffset` over `1s ease` |
| **Pulse** | `pulse-green` keyframe on active-tier badges |
| **Scan line** | `scan-line` keyframe — single vertical sweep on page load, 4s |
| **Accordion** | `height: 0 → auto` with `duration: 0.22` (FAQ) |

**Easing:** mostly default `ease` / `ease-out`. No heavy spring physics, no bouncy overshoots. The motion feels *quiet and deliberate*.

## Layout rules

- **Max content width for marketing:** `1100px` — centered with `margin: 0 auto`.
- **Max content width for app:** `1280px`-ish (varies by page). App pages use full viewport width with consistent 16–24px side padding on mobile.
- **Grids:** `repeat(auto-fill, minmax(min(300px, 100%), 1fr))` is the go-to responsive grid. 16px gap for dense grids, 20–24px for landing.
- **Sticky nav:** always. `position: sticky` on app, `position: fixed` on landing. Height 52px (landing), 60px (app).
- **Mobile breakpoint:** `max-width: 768px` — custom hide/show classes (`.hide-mobile`, `.show-mobile`) rather than Tailwind utilities for nav behavior.

## Imagery / color vibe

The product essentially has no photography or illustrated imagery. The only visual "images" are:

- **Score rings** — SVG circles with animated `strokeDashoffset`
- **Sparklines / mini-charts** — SVG, all rendered in-product (RevenueSparkline, MADistanceBar, ScoreHistoryChart)
- **Logos** — text-only wordmark ("Simu**Alpha**" with italic green "Alpha")

If imagery is ever introduced: cool, low-saturation, dark. Never warm daylight photography.

---

# Iconography

**SimuAlpha barely uses icons at all.** This is deliberate — the visual language leans on typography and color to convey meaning, not glyphs. When icons do appear, they fall into three buckets:

### 1. Unicode geometric shapes (the primary "icon system")

These are baked directly into badge labels in `SignalBadge.jsx`:

| Glyph | Meaning |
|-------|---------|
| `●` (U+25CF) | Active / pulsing signal ("LOAD THE BOAT", "WAVE 3 — WAIT") |
| `◐` (U+25D0) | Half-filled / partial ("ACCUMULATE", "WAVE 4 — ADD") |
| `○` (U+25CB) | Outline / passive ("WATCH") |

Dot + label is the canonical badge form. The color of the dot is the signal color.

### 2. Emoji as badge glyphs (sparingly, never in prose)

Used only inside signal/banner labels where they convey the *mood* of a signal. Examples from the codebase:

- `💎` GENERATIONAL SUPPORT ZONE
- `📐` LEADING DIAGONAL
- `⚠️` ENDING DIAGONAL WARNING
- `🎯` WAVE C COMPLETING
- `⏳` CORRECTION IN PROGRESS
- `✂️` TRIM 50% — WAVE 3 HIT
- `➕` WAVE 4 ADD ZONE
- `💰` TAKE PROFITS — WAVE 5
- `🚨` WAVE B — EXIT LIQUIDITY
- `⛔` THESIS BROKEN
- `🚫` VALUE TRAP
- `🏆` FULL STACK CONSENSUS
- `🏷️` / `🏛` / `🤖` / `📊` — category icons in the consensus banner (super investors, politicians, AI models, TLI)

When emoji appear, they are *always* paired with an all-caps label and a color — never standalone.

### 3. Line icons — not present in codebase, substitution needed

The codebase has **no SVG icon sprite, no icon font, no Lucide/Heroicons import, no .svg files in assets.** There is no general-purpose icon system.

For prototypes that need more icons (search, settings, filters, arrows), **substitute with [Lucide Icons](https://lucide.dev/) via CDN** — stroke-based line icons, 1.5px stroke weight, 20–24px default. Rationale for the match: Lucide is thin-stroked, monochrome, and technical-feeling — consistent with the Plex Mono + hairline-border aesthetic. Use via:

```html
<script src="https://unpkg.com/lucide@latest/dist/umd/lucide.min.js"></script>
<i data-lucide="search"></i>
<i data-lucide="trending-up"></i>
<!-- then: lucide.createIcons(); -->
```

**⚠︎ Flag for the user:** this is a **substitution**. If SimuAlpha later chooses a different icon system, update `SKILL.md` and `ui_kits/*/index.html` accordingly.

### 4. Arrows, checks, bullets — inline characters

The codebase uses typographic characters inline:
- `✓` for feature checkmarks in pricing
- `→` (`&rarr;`) for "View all →" links
- `—` (em-dash) for separators and emphasis in subheads
- `+` / `−` for expand/collapse (FAQ)

These are set in Plex Mono, same size as surrounding text, and colored by context (`--signal-green` for positive confirmation, `--text-dim` for neutral).

---

# Font substitution note

✅ No substitution needed. Both **Cormorant Garamond** and **IBM Plex Mono** are available on Google Fonts and loaded via the `@import` in `colors_and_type.css` and `sources/simualpha/src/index.css`. The brand uses them as-is, no licensed/custom faces.

---

*Not financial advice. For educational and informational purposes only.*

# SimuAlpha Design System — SKILL.md

Use this skill whenever you are designing for **SimuAlpha**, an AI stock-discovery product. It gives you the tokens, typography, voice, and component recipes extracted directly from the live codebase.

## When to invoke

- Designing anything for SimuAlpha (landing, app screens, emails, decks, ads).
- A user mentions SimuAlpha, TLI, Full-Stack Consensus, Load-the-Boat, Elliott Wave signals, or the $10 vs Bloomberg framing.
- A design needs the SimuAlpha aesthetic: **near-black surfaces, Cormorant Garamond + IBM Plex Mono, a single signal-green accent, data-dense tables, micro-sized mono type (9–12px), italic green brand accents on display words.**

## How to use

1. **Read** `README.md` first — it has the full brand context, content rules, visual foundations, and iconography notes.
2. **Include** `colors_and_type.css` at the top of any HTML artifact:
   ```html
   <link rel="stylesheet" href="colors_and_type.css">
   ```
   This exposes every token under `:root`, loads both Google Fonts, sets up the base body + grain overlay, and defines `.ds-*` semantic type roles.
3. **Reference** `ui_kits/marketing/index.html` when building landing/marketing surfaces. Lift nav, hero, stat strip, layer grid, compare table, pricing, footer-CTA patterns from there.
4. **Reference** `ui_kits/app/index.html` when building app surfaces (dashboard, screener, deep-dive, signals). Lift top nav, page header, market risk banner, metric row, Full-Stack Consensus banner, filter chips, screener table rows.
5. **Lift individual components** from `preview/*.html` — each file is a self-contained, copy-pasteable snippet for one component (signal badges, buttons, metric cards, score rings, consensus banner, screener row, market banner).
6. **Before inventing a new component**, check `sources/simualpha/src/components/` — the source-of-truth React components are there. The styling approach is inline-style objects, not className-based; translate to CSS as needed.

## Non-obvious rules (frequently violated)

- **Color = meaning, never decoration.** Green is conviction, amber is caution, red is danger, blue is info, gold is *reserved for Full-Stack Consensus only*. Do not use green to "brighten up" a chart.
- **No pure white.** Text primary is `#f0ede8` (warm cream). No pure black either — surfaces are `#0c0c0e`.
- **Tiny mono type.** Body defaults to **11px**. Labels are 9–10px. Going above 14px for mono means you are *not writing body copy*.
- **Display is always Cormorant, always weight 300 at display sizes**, never bold. Italic-green-accent on the last word is the signature — reach for it often.
- **Buttons do not have hover-scale, hover-shadow, or hover-glow.** Only border-color or background-color changes.
- **No shadows anywhere**, except the `pulse-green` keyframe on active signals.
- **Corners are subtle.** 4px on badges, 6px on buttons, 8–12px on cards. Never pill-shaped. Never fully square either.
- **Emoji only inside signal badges and consensus-layer labels**, never in prose, never as decorative UI glyphs.
- **Icons barely exist.** The "icon system" is `●`, `◐`, `○`, `→`, `—`, `✓` rendered in Plex Mono at the same size as surrounding text. If more icons are needed, substitute **Lucide** via CDN and flag the substitution.
- **Grain overlay is always on.** The `body::before` in `colors_and_type.css` handles it — don't remove it.
- **Always include the disclaimer** at the bottom of any public-facing artifact: *"Not financial advice. AI-generated analysis for educational purposes only. Do your own research before investing."*

## Signal badge canon (do not improvise labels)

Use the exact strings from `preview/components-signals.html`. The full set lives in `sources/simualpha/src/components/SignalBadge.jsx`. Never shorten, retitle, or Title-Case these — they are uppercase, tracked `0.05em`, and paired with the specific dot/emoji glyph shown.

## Voice micro-guide

- Second-person, direct. No "we."
- Numbers as nouns ("8 super investors," "500+ stocks").
- Em-dashes over exclamation points.
- Cormorant italic green for the emotional word; Plex Mono for the technical word.
- Example pattern: `{Aspirational verb}.  {technical qualifier italic green}.` → "Democratizing **Alpha**."  "One Clear **Answer**."

## Files at a glance

| File | When to reach for it |
|------|---------------------|
| `README.md` | Start here. Brand, content, visual foundations, iconography. |
| `colors_and_type.css` | Always include in any artifact. |
| `ui_kits/marketing/index.html` | Building anything `/`-route-shaped (landing, pricing, pitch). |
| `ui_kits/app/index.html` | Building anything `/dashboard`-shaped (tables, metrics, screens). |
| `preview/colors-*.html` | Token review / color reference. |
| `preview/type-*.html` | Typography specimens. |
| `preview/components-*.html` | Single-component snippets to copy-paste. |
| `preview/spacing-*.html` | Radius and spacing scales. |
| `preview/brand-*.html` | Wordmark + iconography reference. |
| `sources/simualpha/` | Source-of-truth React + CSS. Read-only reference. |

## Known gaps / flagged substitutions

- **No proprietary icon set** exists in the repo. Line icons should be substituted with [Lucide](https://lucide.dev/) via CDN, 1.5px stroke, 20–24px. Call this out if the user asks for many icons.
- **No imagery system** — product is text-and-data, no photography or illustration. If a design calls for imagery, ask the user for direction.
- **In-repo `DESIGN_SYSTEM.md` is stale** — it describes a Syne + DM Mono direction that the code no longer uses. This skill reflects what is *actually shipped*, not what that doc says.

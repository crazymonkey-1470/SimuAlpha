# Design System

Drop-in design system for SimuAlpha, extracted from the live frontend code at `frontend/src/`.

## What's here

| Path | Purpose |
|------|---------|
| `index.html` | Cover page — links to everything below. Open this first locally. |
| `README.md` | Brand context, voice rules, visual foundations, iconography. The narrative doc. |
| `SKILL.md` | Agent-invocable reference (Claude Code etc.). Non-obvious rules + signal-badge canon. |
| `colors_and_type.css` | Single drop-in stylesheet. Tokens, base body, grain overlay, semantic type roles. |
| `preview/` | 18 small HTML cards — one per token group / component (palettes, type, badges, score ring, etc). |
| `ui_kits/marketing/` | Full landing-page reference (`/` route). |
| `ui_kits/app/` | Full screener/dashboard reference (`/dashboard` route). |

## How to use from a feature branch

The `colors_and_type.css` file mirrors and slightly reorganizes what's already in `frontend/src/index.css` — same tokens, same fonts. You can either:

- Reference this folder as the source of truth for **new** designs and prototypes (recommended), and let `frontend/src/index.css` continue to be the runtime stylesheet.
- Or, longer term, replace the inline `:root` block in `frontend/src/index.css` with `@import './design-system/colors_and_type.css';` so the runtime and the docs share one definition.

## Notes / flagged substitutions

- **Icons**: the repo has no icon set today. The system documents `●`, `◐`, `○`, `→`, `—`, `✓` (Plex Mono glyphs) as the primary "icon system," and recommends [Lucide](https://lucide.dev/) via CDN if more line icons are needed. Update if the project standardizes on something else.
- **Stale doc**: the existing `DESIGN_SYSTEM.md` in the repo describes a Syne + DM Mono direction the code no longer uses. This folder reflects what's *actually shipped* (Cormorant Garamond + IBM Plex Mono). Consider deleting or replacing the old doc once this lands.

## Suggested PR title

> docs(design-system): add extracted design system + UI kits

## Suggested PR body

> Adds a self-contained `design-system/` folder documenting the brand, tokens, components, and two full UI kit references (marketing + app), all extracted directly from `frontend/src/`. Includes:
>
> - `README.md` + `SKILL.md` for human and agent consumption
> - `colors_and_type.css` — drop-in tokens that mirror `frontend/src/index.css`
> - 18 component/token preview cards under `preview/`
> - Full landing + app reference layouts under `ui_kits/`
>
> Flags the existing `DESIGN_SYSTEM.md` as stale (Syne/DM Mono no longer in use). No runtime code touched.
